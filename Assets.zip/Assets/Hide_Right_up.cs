using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_Right_up : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 56);
        Invoke("Hide", 60);
        Invoke("Wake", 76);
        Invoke("Hide", 80);
        Invoke("Wake", 84);
        Invoke("Hide", 88);
        Invoke("Wake", 152);
        //Invoke("Hide", 156);
        //Invoke("Wake", 172);
        //Invoke("Hide", 176);
        //Invoke("Wake", 180);
        Invoke("Hide", 192);
       

    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
