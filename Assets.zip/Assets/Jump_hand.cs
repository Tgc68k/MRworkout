using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jump_hand : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 145);
        Invoke("Hide", 153);
        Invoke("Wake", 192);
        Invoke("Hide", 212);
       


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
