using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_L_hands : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 4);
        Invoke("Hide", 8);
        Invoke("Wake", 12);
        Invoke("Hide", 16);
        Invoke("Wake", 36);
        Invoke("Hide", 40);
        Invoke("Wake", 108);
        Invoke("Hide", 112);
        Invoke("Wake", 132);
        Invoke("Hide", 136);
        


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
