using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hand_plate : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        //Invoke("Wake", 4);
        //Invoke("Hide", 8);
        Invoke("Wake", 28);
        Invoke("Hide", 32);
        Invoke("Wake", 52);
        Invoke("Hide", 56);
        Invoke("Wake", 100);
        Invoke("Hide", 104);
        Invoke("Wake", 124);
        Invoke("Hide", 128);



    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
