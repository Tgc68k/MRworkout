using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_R_L_hands : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 16);
        Invoke("Hide", 20);
        Invoke("Wake", 40);
        Invoke("Hide", 44);
        Invoke("Wake", 112);
        Invoke("Hide", 116);
        Invoke("Wake", 136);
        Invoke("Hide", 140);
      


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
