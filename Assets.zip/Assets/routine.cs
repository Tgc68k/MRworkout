using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class routine : MonoBehaviour
{
    // Start is called before the first frame update
   

    // Update is called once per frame
    float alpha_Sin;

    void Update()
    {
        alpha_Sin = Mathf.Sin(Time.time) / 2 + 0.5f;
    }
}
