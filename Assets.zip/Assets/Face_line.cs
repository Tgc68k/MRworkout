using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Face_line : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        //Invoke("Wake", 10);
        //Invoke("Hide", 4);
        Invoke("Wake", 24);
        Invoke("Hide", 28);
        Invoke("Wake", 48);
        Invoke("Hide", 52);
        Invoke("Wake", 96);
        Invoke("Hide", 100);
        Invoke("Wake", 120);
        Invoke("Hide", 124);
       


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
