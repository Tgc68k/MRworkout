using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_R_hands : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 0);
        Invoke("Hide", 4);
        Invoke("Wake", 8);
        Invoke("Hide", 12);
        Invoke("Wake", 32);
        Invoke("Hide", 36);
        Invoke("Wake", 104);
        Invoke("Hide", 108);
        Invoke("Wake", 128);
        Invoke("Hide", 132);
        


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
