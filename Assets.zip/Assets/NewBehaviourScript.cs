using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{

    public AudioClip sound1;
    AudioSource audioSource;

    void Start()
    {
        //Component���擾
        audioSource = GetComponent<AudioSource>();
        //GetComponent<Renderer>().material.color = Color.blue;
    }

    void Update()
    {
        var d = Vector3.Distance(Camera.main.transform.position, transform.position);
        if (d <= 0.3)�@//�����蔻��͈̔́@�����l0.1
        {
            //��(sound1)��炷
            audioSource.PlayOneShot(sound1);
            //GetComponent<Renderer>().material.color = Color.red;
            //GetComponent<Renderer>().material.color = Color.blue;
        }
       
        if (d >= 10)
        {
            
            //GetComponent<Renderer>().material.color = Color.blue;
        }
    }
}
