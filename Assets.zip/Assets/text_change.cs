using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class text_change : MonoBehaviour
{
    // Start is called before the first frame update
    private TextMesh changeText;

    void Start()
    {

        Invoke("Change_Stand", 56);

        Invoke("Change_Squat", 96);

        Invoke("Change_Stand", 152);

        Invoke("Change_Squat", 140);

        Invoke("Change_Jump", 144);

        

        Invoke("Change_Stand", 153);

        Invoke("Change_Squat", 154);

        Invoke("Change_Stand", 182);

        Invoke("Change_Jump", 192);

        Invoke("Change_Finished", 212);

    }

    void Change_Finished()
    {
        changeText = GetComponentInChildren<TextMesh>();
        changeText.text = "Finished";
    }

    void Change_Stand()
    {
        changeText = GetComponentInChildren<TextMesh>();
        changeText.text = "Stand";
    }

    void Change_Squat()
    {
        changeText = GetComponentInChildren<TextMesh>();
        changeText.text = "Squat";
    }

    void Change_Jump()
    {
        changeText = GetComponentInChildren<TextMesh>();
        changeText.text = "Jump";
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
