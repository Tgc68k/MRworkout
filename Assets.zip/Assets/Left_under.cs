using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Left_under : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 60);
        Invoke("Hide", 64);
        Invoke("Wake", 68);
        Invoke("Hide", 72);
        Invoke("Wake", 88);
        Invoke("Hide", 92);
        Invoke("Wake", 154);

        Invoke("Hide", 190);
        //Invoke("Wake", 184);
        //Invoke("Hide", 188);
     



    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
