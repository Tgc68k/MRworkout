using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Microsoft.MixedReality.Toolkit.Input;
using Microsoft.MixedReality.Toolkit.UI;

using UnityEngine.UI;

namespace Microsoft.MixedReality.Toolkit.Examples.Demos
{ 
public class NewBehaviourScript_collision_range_small : MonoBehaviour
{

    public AudioClip sound1;
    AudioSource audioSource;


    public CountText countText;

    public TextMesh scoreText;

    private int x = 0;

        void Start()
    {
        //Component���擾
        audioSource = GetComponent<AudioSource>();
        //GetComponent<Renderer>().material.color = Color.blue;
    }

        

        void Update()
    {
        var d = Vector3.Distance(Camera.main.transform.position, transform.position);
        GameObject Hands;

        CountText script;
        if ((d <= 0.3) && (x == 0)) �@//�����蔻��͈̔́@�����l0.1
        {
            //��(sound1)��炷
            audioSource.PlayOneShot(sound1);

            Hands = GameObject.Find("Hands");
            script = Hands.GetComponent<CountText>();
            script.Action();
            script.Attack();
            x += 1;
            Invoke(nameof(DelayMethod), 1.0f);
                //GetComponent<Renderer>().material.color = Color.red;
                //GetComponent<Renderer>().material.color = Color.blue;
            }

        if (d >= 10)
        {

            //GetComponent<Renderer>().material.color = Color.blue;
        }
    }
        void DelayMethod()
        {
            x -=1;
        }
    }
}
