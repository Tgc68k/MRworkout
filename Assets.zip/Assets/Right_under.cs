using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Right_under : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 64);
        Invoke("Hide", 68);
        Invoke("Wake", 92);
        Invoke("Hide", 96);
        Invoke("Wake", 160);
        Invoke("Hide", 164);
        Invoke("Wake", 188);
        Invoke("Hide", 192);
       

    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
