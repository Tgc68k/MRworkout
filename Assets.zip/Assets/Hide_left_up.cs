using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_left_up : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 58);
        //Invoke("Hide", 24);
        //Invoke("Wake", 72);
        Invoke("Hide", 98);
        //Invoke("Wake", 80);
        //Invoke("Hide", 84);
        Invoke("Wake", 153);
       // Invoke("Hide", 24);
        //Invoke("Wake", 168);
        //Invoke("Hide", 172);
        //Invoke("Wake", 176);
        Invoke("Hide", 189);
     
 


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
