using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hide_L_R_hands : MonoBehaviour
{
    // Start is called before the first frame update

    public float timeCount = 5;
    private float timeElapsed;

    void Start()
    {
        this.gameObject.SetActive(false);
        Invoke("Wake", 2);
        Invoke("Hide", 18);
        Invoke("Wake", 20);
        Invoke("Hide", 24);
        Invoke("Wake", 34);
        Invoke("Hide", 42);
        Invoke("Wake", 44);
        Invoke("Hide", 48);
        Invoke("Wake", 106);
        //Invoke("Hide", 122);
        //Invoke("Wake", 126);
        Invoke("Hide", 138);
        Invoke("Wake", 140);
        Invoke("Hide", 144);
       


    }

    // Update is called once per frame
    void Wake()
    {
        this.gameObject.SetActive(true);
    }

    void Hide()
    {
        this.gameObject.SetActive(false);
    }
}
